/* Polynomial represents a function raised to a power.
 * Author: Lutfi Yigit Saglam
 */ 

public class Polynomial implements Function
{
  private Function operand;
  private double power;
  
  /* takes two values
   * @param operand
   * @param power 
   */
  public Polynomial(Function operand, double power)
  {
    this.operand = operand;
    this.power = power;
  }
  
  /* The Polynomial type should have a getOperand
   * return operand
   */
  public Function getOperand()
  {
    return this.operand;
  }
  
  /* The Polynomial type should have a getPower
   * return power
   */
  public double getPower()
  {
    return this.power;
  }
  /* return Math.pow for the operand.value() and power
   */
  
  public double value()
  {
    return Math.pow(operand.value(),power);
  }
  /* return Math.pow for the operand.value(x) and power
   */ 
  public double value(double x)
  {
    return Math.pow(operand.value(x),power);    
  }
  
  /* power comes head and decreases by 1.
   */
 
  public Function derivative()
  {
    Function operandDerivative = operand.derivative();
    
    Function derivative = new BinaryOp<>(BinaryOp.Operator.MULT,
    new Number(power),
    new BinaryOp<>(BinaryOp.Operator.MULT,new Number(Math.pow(operand.value(),power-1)),
    operandDerivative));
    return derivative;
    
  }
  
  
  
  
  
  
}