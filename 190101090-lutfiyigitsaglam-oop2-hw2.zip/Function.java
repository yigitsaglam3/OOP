public interface Function
{
  double value(double x);
  double value();
  Function derivative();
  
  
}