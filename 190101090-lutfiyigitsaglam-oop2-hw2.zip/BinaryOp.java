/* represents a binary operator (+, -, *, /) and two function operands
 * Author: Lutfi Yigit Saglam
 */ 
public class BinaryOp <T extends Function> implements Function
{
 
enum Operator
  {
  PLUS,SUB,MULT,DIV;
  }
  
  
  
  private final Operator operator;
  private T leftOperand;    
  private T rightOperand;
  
  /* constructor should take three values
   * @param Operator operator
   * @param T leftOperand
   * @param T rightOperand
   */ 
  public BinaryOp (Operator operator, T leftOperand, T rightOperand)
  {
    
    this.operator = operator;
    this.leftOperand = leftOperand;
    this.rightOperand = rightOperand;
  }
  
  /*The BinaryOp type should have the getter methods getOperator
   * return operator
   */
  Operator getOperator()
  {
    return operator;
  }
  
  /*The BinaryOp type should have the getter methods getLeftOperator
   * return leftOperand
   */ 
  T getLeftOperand()
  {
    return leftOperand;
  }
  
  /*The BinaryOp type should have the getter methods getRightOperator
   * return rightOperand
   */ 
  T getRightOperand()
  {
   return rightOperand;
  }
    
  /* if one of them is not a Number, it will throw exception for value()
   * if both of them is a Number, it will come inside to switch statement
   * return value()
   */ 
  public double value()
  {
    if( getRightOperand() instanceof Number || getLeftOperand()instanceof Number )
    {
      switch(operator)
      {
      case PLUS:
        return getLeftOperand().value() + getRightOperand().value();
      case SUB:
        return getLeftOperand().value() - getRightOperand().value();
      case MULT:
        return getLeftOperand().value() * getRightOperand().value();
      case DIV:
        return getLeftOperand().value() / getRightOperand().value();
        
      }  
    }
    else
      throw new UnsupportedOperationException();
    return value() ;
  }
  /* if one of them is not a Number, it will throw exception for value(double x)
   * if both of them is a Number, it will come inside to switch statement
   * return value(x)
   */ 
  public  double value(double x)
  {
    if (getRightOperand() instanceof Number || getLeftOperand() instanceof Number)
    {    
      switch (operator)
      {   
        case PLUS:          
          return getLeftOperand().value(x) + getRightOperand().value(x);
        case SUB:
          return getLeftOperand().value(x) - getRightOperand().value(x);
        case MULT:
          return getLeftOperand().value(x) * getRightOperand().value(x);
        case DIV:
          return getLeftOperand().value(x) / getRightOperand().value(x);
      }
    } 
    else
    {     
      throw new UnsupportedOperationException(); 
    }
      return value(x);
    
  }
  /* take derivative for left and right operand
   * for plus; leftDerivative + rightDerivative
   * for sub; leftDerivative - rightDerivative
   * for mult; leftOperand.derivative*rightOperand + rightOperand.derivative*leftOperand
   * for div; (leftOperand.derivative*rightOperand - rightOperand.derivative*leftOperand)/rightOperand*rightOperand 
   */ 
  public Function derivative()
  { 
    Function leftDerivative = leftOperand.derivative();
    Function rightDerivative = rightOperand.derivative();
    switch (operator) {
            case PLUS:
                return new BinaryOp<>(Operator.PLUS, leftDerivative, rightDerivative);
            case SUB:
                return new BinaryOp<>(Operator.SUB, leftDerivative, rightDerivative);
            case MULT:
                return new BinaryOp<>(Operator.PLUS,
                        new BinaryOp<>(Operator.MULT, leftOperand.derivative(), rightOperand),
                        new BinaryOp<>(Operator.MULT, leftOperand, rightOperand.derivative()));
            case DIV:
                return new BinaryOp<>(Operator.DIV,
                        new BinaryOp<>(Operator.SUB,
                                new BinaryOp<>(Operator.MULT, leftOperand.derivative(), rightOperand),
                                new BinaryOp<>(Operator.MULT, leftOperand, rightOperand.derivative())),
                        new BinaryOp<>(Operator.MULT, rightOperand, rightOperand));
            default:
                throw new UnsupportedOperationException();
        }
  }
  /*The toString representation should be left-operand op right-operand where op is one of +, -, *, /. 
   * (Note the single space between each operand and the operator.)  
   */ 
  public String toString()
  {
    
    String leftString = leftOperand.toString();
    String rightString = rightOperand.toString();
    if (leftOperand instanceof BinaryOp && ((BinaryOp<?>) leftOperand).operator != operator)
    {
      leftString = "(" + leftString + ")";
    }
    if (rightOperand instanceof BinaryOp && ((BinaryOp<?>) rightOperand).operator != operator)
    {
      rightString = "(" + rightString + ")";
    }
    String operatorString = "";
    switch (operator)
    {
      
      case PLUS:
        operatorString = " + ";
        break;
      case SUB:
        operatorString = " - ";
        break;
      case MULT:
        operatorString = " * ";
        break;
      case DIV:
        operatorString = " / ";
        break;
    }
     return leftString + operatorString + rightString;
    }
   
}
