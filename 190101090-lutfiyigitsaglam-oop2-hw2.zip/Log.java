import java.lang.Math;
public class Log implements Function
{
  private Function operand;
  
  /* The constructor should take a single value
   * @param operand
   */ 
  public Log(Function operand)
  {
    this.operand = operand;
  }
  
  /* the type should have a getOperand method.
   * return operand
   */
  public Function getOperand()
  {
    return operand;
  }
  
  /* return Math.exp for the value()
   */
  public double value()
  {
    return Math.exp(operand.value());
  }
  
  /* return Math.exp for the value(x)
   */
  public double value(double x)    
  {
    return Math.exp(operand.value(x));
  }
  
  /* derivative of log
   * derivative of operand / operand
   */
  public Function derivative()
  {
    Function operandDerivative = operand.derivative();
    return new BinaryOp<>(BinaryOp.Operator.DIV,operandDerivative,operand);
    
  }

  
  
}