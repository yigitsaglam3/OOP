/* Number represents a number as a double
 * @author: Lutfi Yigit Saglam 
 */ 

public class Number implements Function
{
  private double value;
  
  /* constructor
   * @param double value
   */ 
  public Number (double value)
  {
    this.value = value;
  }
  /* get value
   */ 
  public double getValue()
  {
    return this.value;
  }
  
 /* for value()
  */ 
  public double value()
  {
    return value;
  }
  
  /* for value(double x)
   */ 
  public double value(double x)
  {
    return value;
  }
  
  /* derivative of value
   */ 
  public Function derivative()
  {
    return new Number(0);
  }
  
  /*The toString method should give a String representation of the number
   */ 
  @Override
  public String toString() 
  {
    return Double.toString(value);
  }
  
  /* the equals should compare the number values.
   */ 
  @Override
  public boolean equals(Object obj)
  {
     if (obj instanceof Number)
       {
          Number other = (Number) obj;
          return value == other.value;
       }
        return false;
  }
}