/* A class represent Variable
 * @Author: Lutfi Yigit Saglam
 * 
 */ 
public class Variable implements Function
{
  //Constructor does not take an input
  public Variable()
  {
    
  }
  /* if there is no input,it will throw exception
   */ 
  public double value()
  {
    throw new UnsupportedOperationException
      ("Variable value cannot be computed without an input");
  }
  /* if there is an input, it will return x
   */ 
  public double value (double x)
  {
    return x;
  }
  
  public Function derivative()
  {
    return new Number(1);
  }
  /* The toString method should just give "x"
   */ 
  @Override
   public String toString()
  {
    return "x";
  }
  
  /* the equals method should return true if this object is compared to another Variable
   */ 
  @Override
  public boolean equals(Object obj)
  {
    return !(this==obj); 
     
  }
  
}