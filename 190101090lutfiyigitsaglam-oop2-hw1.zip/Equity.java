/* An Equity class represents an asset where you can own shares of the asset
 * @Author: Lutfi Yigit Saglam
 */
public class Equity extends Asset
{
  private char symbol;
  private double numberSharesOwned;
  
 /* Constructor of a Equity class
 * @param name of the equity
 * @param symbol
 * @param currentPrice
 */ 
  public Equity(String name, char symbol, double currentPrice)
  {
    super(name,0);
    this.symbol = symbol;
    this.numberSharesOwned = 0;
    super.setCurrentPrice(currentPrice);
    
  }
  /*returns single character symbol of the equity
   *@return symbol
   */
  public char getSymbol()
  {
    return symbol;
  }
  /*returns the number of shares of the equity
   *@return numberSharesOwned
   */
  public double getNumberSharesOwned()
  {
    return numberSharesOwned;
  }
  /*input value is the number of shares of the equity
   * @param numberSharesOwned
   */
  public void setNumberSharesOwned(double numberSharesOwned)
  {
    this.numberSharesOwned = numberSharesOwned;
  }
  
}