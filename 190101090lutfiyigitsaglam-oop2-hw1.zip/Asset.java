/* The Asset class represents any tangible property that has a value
 * @Author: Lutfi Yigit Saglam
 */
public class Asset
{
  private String name;
  private String description;
  private double costBasis;
  private double currentPrice;
  private double capitalGains;
  
  /* Constructor of an Asset class.
   * @param name the name of Asset
   * @param costBasis the cost basis of Asset
   */  
  public Asset(String name, double costBasis)
  {
    this.name = name;
    this.costBasis = costBasis;
    this.capitalGains = 0.0;
  }
  
  /* methods gives name of the asset
   * @return name
   */
  public String getName()
  {
    return name;
  }
  /*sets the name of the asset
   * @param name
   */ 
  public void setName(String name)
  {
    this.name = name;
  }
  /* methods returns a description of what the asset is
   * @return description
   */
  public String getDescription()
  {
    return description;
  }
  /* sets the description of the asset
   * @param description
   */
  public void setDescription(String description)
  {
    this.description = description;
  }
  /* returns the cost basis of the asset
   * @return costBasis
   */
  public double getCostBasis()
  {
    return costBasis;
  }
  /* changes the cost basis of the asset
   * @param costBasis
   */
  public void setCostBasis(double costBasis)
  {
    this.costBasis = costBasis;
  }
  /* returns current price of the asset
   * @return currentPrice
   */
  public double getCurrentPrice()
  {
    return currentPrice;
  }
  /* the input value is the current price of the asset
   * @param currentPrice
   */
  public void setCurrentPrice(double currentPrice)
  {
    this.currentPrice = currentPrice;
  }
  /* returns the capital gains from the asset
   * @return capitalGains
   */
  public double getCapitalGains()
  {
    return capitalGains;
  }
  /* changes the capital gains of the asset
   * @param capitalGains
   */
  public void setCapitalGains(double capitalGains)
  {
    this.capitalGains = capitalGains;
  }
  
  
}