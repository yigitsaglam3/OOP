/* The Customer class represents a customer account.
 * @Author: Lutfi Yigit Saglam
 */
public class Customer
{
  private Bond bond;
  private MutualFund mutualFund;
  private double totalCash;
  private String firstName;
  private String lastName;
  
  /* Constructor of a Customer class
  * @param bond 
  * @param mutualFund
  * @param total cash of the customer
  * @param first name of the customer
  * @param last name of the customer
  */ 
  public Customer(Bond bond, MutualFund mutualFund,double totalCash,String firstName,String lastName)
  {
    this.bond = bond;
    this.mutualFund = mutualFund;
    this.totalCash = totalCash;
    this.firstName = firstName;
    this.lastName = lastName;  
  }
  /* returns first name of the customer
   * @return firstName
   */
  public String getFirstName()
  {
    return firstName;
  }
  /* changes the first name of the customer
   * @param firstName
   */
  public void setFirstName(String firstName)
  {
    this.firstName = firstName;
  }
  /* returns the last name of the customer
   * @return lastName
   */
  public String getLastName()
  {
    return lastName;
  }
  /* changes the last name of the customer
   * @param lastName
   */
  public void setLastName(String lastName)
  {
    this.lastName = lastName;
  }
  /* returns a bond associated with this account
   * @return bond
   */
  public Bond getBond()
  {
    return bond;
  }
  /* changes the bond associated with this account
   * @param bond
   */ 
  public void setBond(Bond bond)
  {
    this.bond = bond;
  }
  /* returns mutual fund associated with this account
   * @return mutualFund
   */
  public MutualFund getMutualFund()
  {
    return mutualFund;
  }
  /* changes the mutual fund associated with this account
   * @param mutualFund
   */
  public void setMutualFund(MutualFund mutualFund)
  {
    this.mutualFund = mutualFund;
  }
  /* returns current price of the bond times the number of bonds owned 
   * plus the number of shares times the current price for the mutual fund
   * @return value
   */
  public double currentValue()
  {
    if(bond.getCurrentPrice() != 0 && bond.getNumberOwned() != 0 && mutualFund.getNumberSharesOwned() !=0 && mutualFund.getCurrentPrice() !=0)
    {
      return (bond.getCurrentPrice()*bond.getNumberOwned()) + (mutualFund.getNumberSharesOwned()*mutualFund.getCurrentPrice()); 
      
    }
    else
    {
    return 0;
    }
  }
  /* Returns the sum of the capital gains of the bond and mutual fund
   * @return getBond().getCapitalGains()+getMutualFund().getCapitalGains()
   */
  public double getCapitalGains()
  {
     if(bond.getCapitalGains() != 0 && mutualFund.getCapitalGains()!= 0)
     {
       return bond.getCapitalGains()+ mutualFund.getCapitalGains();
     }
     else
     {
       return 0;
     }
  }
  /*Calls the bond’s sell method and 
   *deposits the value returned into the customer’s total cash. 
   */
  public void sellBond()
  {
    totalCash += bond.sell();
  }
  /*If the current price of the bond is larger than the customer's total cash,
   * the method returns false and does nothing else.
   */
  public boolean buyBond()
  {
    if(bond.getCurrentPrice()>totalCash)
    {
      return false;
    }
    else
    {
      totalCash -= bond.buy();
      return true;
    }
    
  }
  /*Calls the mutual fund’s sell method with this number and
   *adds the amount returned to thetotal cash.
   * 
   */
  public void withdrawMutualFund(double withdrawAmount)
  {
    totalCash += mutualFund.sell(withdrawAmount);  
  }
  /*If the input value is larger than the total cash of the customer,
   *the method returns false and does nothing else
   *Otherwise, the method call’s the mutual fund’s buy method with the input value
   *the total cash is reduced by the amount returned from the buy method and
   * true is returned. 
   */
  public boolean buyMutualFund(double buyMutualFund)
  {
    if(buyMutualFund>totalCash)
    {
      return false;
    }
    else
    {
      totalCash -= mutualFund.buy(buyMutualFund);
      return true;
    }
  }
  
   
   
  
  
  
  
}