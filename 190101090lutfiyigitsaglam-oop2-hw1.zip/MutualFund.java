/* A MutualFund class instance
 * represents an equity that is the shares of a mutual fund
 * @Author: Lutfi Yigit Saglam
 */
public class MutualFund extends Equity
{
  private double load;
  
 /* Constructor of a MutualFund class
 * @param name of the mutual fund
 * @param symbol
 * @param currentPrice
 */ 
  public MutualFund(String name, char symbol,double currentPrice)
  {
    super(name,symbol,currentPrice);
    this.load = 0.0;
  }
  /*Returns the current load of the mutual fund
   * @return load
   */
  public double getLoad()
  {
    return load;
  }
  /*Changes the load of the mutual fund to be the input value.
   * @param load
   */
  public void setLoad(double load)
  {
    this.load = load;
  }
  /* takes a double as input that 
   * the amount of money you are investing in the mutual fund
   * @return amount
   */
  public double buy(double amount)
  {
    if(amount<0)
    {
      return 0;
    }
    else
    {
       double x = amount * (1 - this.load/100)/this.getCurrentPrice();
       
       
       return amount;
    }
     
  }
  /*If the input number is not positive or is larger than the current value of the mutual fund return 0
   * @return 0
   * Otherwise, the number of shares owned is decreased by amount withdrawn / current price
   * The cost basis is decreased by the ratio of the number of shares sold to the number of shares owned prior to this sale
   * The capital gains is increased by the difference between the amount withdrawn and the amount that the cost basis decreased
   * @return withdrawnAmount
   */
  public double sell(double withdrawnAmount)
    {
      if(withdrawnAmount <=0 || withdrawnAmount > (getCurrentPrice()*getNumberSharesOwned()))
      {
        return 0;
      }
      else
      {
        double decreasedNumberSharesOwned = getNumberSharesOwned() - (withdrawnAmount/getCurrentPrice());
        double decreasedCostBasis = getCostBasis() - (decreasedNumberSharesOwned/getNumberSharesOwned());
        double increasedCapitalGains = getCapitalGains() + (withdrawnAmount - decreasedCostBasis);
        return withdrawnAmount;
        
      }
    }
  

  }