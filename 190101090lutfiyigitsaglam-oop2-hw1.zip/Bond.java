/* A Bond class instance represents an asset that is a loan
 * from a government or corporation
 * @Author: Lutfi Yigit Saglam
 */
public class Bond extends Asset
{
  private double principal;
  private int numberOwned;
  private double interestRate;
 
/* Constructor of a Bond class
 * @param name of the bond
 * @param principal of the bond
 * @param interestRate of the bond
 */ 
  public Bond(String name, double principal, double interestRate)
  {
    super(name,0);
    this.principal = principal;
    this.interestRate = interestRate;    
  }
  
  /* returns the principal of the bond
   * @return principal
   */
  public double getPrincipal()
  {
    return principal;
  }
  /* returns input that is the number of bonds owned
   * @return numberOwned
   */
  public int getNumberOwned()
  {
    return numberOwned;
  }
  /* changes the number of the bond to input
   * @param number
   */
  public void setNumberOwned(int number)
  {
    this.numberOwned = number;
  }
  /* returns the interest rate of the bond
   * @return interestRate
   */
  public double getInterestRate()
  {
    return interestRate;
  }
  /* changes the interest rate for the bond to input
   * @param intRate
   */
  public void setInterestRate(double intRate)
  {
    this.interestRate = intRate;
  }
  /* returns the product of the interest rate and principal
   * @return principal*interestRate
   */ 
  public double payInterest()
  {
    return getPrincipal()*getInterestRate();
  }
  /* cost basis is increased
   * returns current price 
   * and number of bond owned is increased
   * 
   */
  public double buy()
  {
    double setcostBasis = getCostBasis() + getCurrentPrice();
    numberOwned += 1;
    return getCurrentPrice();
    
  }
  /*. If there are no bonds owned, the method returns 0
   * else , the cost basis is reduced by (cost basis / number of bonds owned)
   * the capital gains is increased by the difference between the current price and the amount the cost basis was reduced
   * the number of bonds owned is decreased by 1
   * @return getCurrentPrice()
   */
  public double sell()
  {
    if(numberOwned == 0)
    {
      return 0;
    }
    else
    {
      double reducedCostBasis = getCostBasis() - (getCostBasis()/getNumberOwned());
      double increasedCapitalGains = getCapitalGains() + (getCurrentPrice()-reducedCostBasis);
      numberOwned --;
      return getCurrentPrice();
    }
     
  }
  
}


